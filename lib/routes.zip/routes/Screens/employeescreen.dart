import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Employeescreen extends StatefulWidget {
  const Employeescreen({super.key});

  @override
  State<Employeescreen> createState() => _EmployeescreenState();
}

class _EmployeescreenState extends State<Employeescreen> {
  final _formKey = GlobalKey<FormState>();

  final _name = TextEditingController();
  final _position = TextEditingController();
  final _salary = TextEditingController();

  int _selectedDayIndex = 0; // 0..4
  final _days = const ['ចន្ទ', 'អង្គារ', 'ពុធ', 'ព្រហ', 'សុក្រ'];

  @override
  void dispose() {
    _name.dispose();
    _position.dispose();
    _salary.dispose();
    super.dispose();
  }

  void _save() {
    if (!(_formKey.currentState?.validate() ?? false)) return;

    final data = {
      'name': _name.text.trim(),
      'position': _position.text.trim(),
      'salary': int.tryParse(_salary.text.trim()) ?? 0,
      'day': _days[_selectedDayIndex],
    };

    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text('Saved: $data')));
  }

  @override
  Widget build(BuildContext context) {
    final color = const Color(0xFF0B5D57);

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'បន្ថែម/កែសម្រួល',
              style: GoogleFonts.hanuman(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'បុគ្គលិក',
              style: GoogleFonts.hanuman(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),

      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
            children: [
              Center(
                child: Stack(
                  alignment: Alignment.bottomRight,
                  children: [
                    CircleAvatar(
                      radius: 46,
                      backgroundColor: Colors.grey.shade200,
                      child: Icon(
                        Icons.person,
                        size: 46,
                        color: Colors.grey.shade500,
                      ),
                    ),
                    Material(
                      color: color,
                      shape: const CircleBorder(),
                      child: InkWell(
                        customBorder: const CircleBorder(),
                        onTap: () {},
                        child: const Padding(
                          padding: EdgeInsets.all(10),
                          child: Icon(
                            Icons.camera_alt,
                            color: Colors.white,
                            size: 20,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              const Text('ឈ្មោះនិយោជិត'),
              const SizedBox(height: 8),
              TextFormField(
                controller: _name,
                decoration: const InputDecoration(
                  hintText: 'សុខ នា',
                  border: OutlineInputBorder(),
                ),
                validator: (v) {
                  if (v == null || v.trim().isEmpty) return 'សូមបញ្ចូលឈ្មោះ';
                  return null;
                },
              ),
              const SizedBox(height: 14),

              const Text('តួនាទី'),
              const SizedBox(height: 8),
              TextFormField(
                controller: _position,
                decoration: const InputDecoration(
                  hintText: 'អនុប្រធានផ្នែក',
                  border: OutlineInputBorder(),
                ),
                validator: (v) {
                  if (v == null || v.trim().isEmpty) return 'សូមបញ្ចូលតួនាទី';
                  return null;
                },
              ),
              const SizedBox(height: 14),

              const Text('ប្រាក់ខែ'),
              const SizedBox(height: 8),
              TextFormField(
                controller: _salary,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  hintText: '850',
                  border: OutlineInputBorder(),
                  suffixIcon: Icon(Icons.monetization_on_outlined),
                ),
                validator: (v) {
                  final n = int.tryParse((v ?? '').trim());
                  if (n == null) return 'សូមបញ្ចូលលេខប្រាក់ខែ';
                  if (n < 0) return 'ប្រាក់ខែ​មិនអាចតិចជាង 0';
                  return null;
                },
              ),
              const SizedBox(height: 16),

              const Text('ថ្ងៃធ្វើការ'),
              const SizedBox(height: 10),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: List.generate(_days.length, (i) {
                  final selected = _selectedDayIndex == i;
                  return ChoiceChip(
                    label: Text(_days[i]),
                    selected: selected,
                    onSelected: (_) => setState(() => _selectedDayIndex = i),
                    selectedColor: color.withOpacity(0.18),
                    side: BorderSide(
                      color: selected ? color : Colors.grey.shade400,
                    ),
                    labelStyle: TextStyle(
                      color: selected ? color : Colors.black87,
                    ),
                  );
                }),
              ),

              const SizedBox(height: 22),
              SizedBox(
                height: 52,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: color,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onPressed: _save,
                  icon: const Icon(Icons.save),
                  label: const Text('រក្សាទុក'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
